Placeholder for completion sound

To complete the sound functionality:
1. Add an MP3 or WAV file named "completion.mp3" or "completion.wav" in this sounds folder
2. The sound should be a short celebration sound (1-3 seconds recommended)
3. Suggested sounds: success chime, celebration sound, ding, applause, etc.

The extension will automatically try to load:
- sounds/completion.mp3
- sounds/completion.wav

Make sure the file is not too large (< 1MB recommended) for better performance.
